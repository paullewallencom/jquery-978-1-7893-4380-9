$(document).ready(function(){

    
    $("h1").text("HELLO World").removeClass("red");
    $("h1").addClass("yellow");
    $("div").toggleClass("red");
    
    
    
/*
    $("h1").html("jQUERY COURSE <br> SECTION 1");
    $("#myId").text("THis can be anything");
    $("h1").remove();
    $("li").append("APPEND");
    $("li").prepend("PREPEND");

    $("li").css({color:"red"});
    $("#myId").css({color:"blue"});
    $(".myClass").css({color:"green"});
 */   

    
});



/*
$(function(){

});
*/

