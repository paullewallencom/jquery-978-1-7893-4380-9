$(document).ready(function(){
$("img").attr("src","https://via.placeholder.com/50x100");
    $("input:text[name=first]").val("hello world");
    $("a").attr({
        href:"http://www.google.com",
        title:"Out to Google"
    });
    $("#checkBox").prop("checked",true);

});




