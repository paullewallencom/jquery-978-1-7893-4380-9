 var myData = {
            "projects": [
                {
                    "name": "Learn jQuery"
                    , "status": "New"
                    , "due": "2020-10-05"
                    , "output": "course"
                    , "lessons": 200
                    , "active": true
                  }
                  , {
                    "name": "Learn JavaScript"
                    , "status": "Active"
                    , "due": "2020-06-05"
                    , "output": "course"
                    , "lessons": 100
                    , "active": true
                  }
                  , {
                    "name": "Learn HTML"
                    , "status": "Done"
                    , "due": "2019-06-05"
                    , "output": "course"
                    , "lessons": 50
                    , "active": true
                  }
              ]
        }